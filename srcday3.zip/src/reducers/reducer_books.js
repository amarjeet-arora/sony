export default function(){
    return [

           {title:'angularJS Book',price:300},
           { title:'ReactJS Book',price: 240},
           { title:'MongoDB Book',price:400},

        
    ]
}