import React from 'react'




const App =() =>{
    return (

        <h2>welcome to my component</h2>
    )
}

export default App;