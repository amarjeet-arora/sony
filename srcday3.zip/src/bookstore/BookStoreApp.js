import React from 'react'
import BookDetails from './BookDetails'
import BookList from './BookList'




const BookStoreApp =() =>{
    return (

       <div>
           <BookDetails/>
           <BookList/>
       </div>
    )
}

export default BookStoreApp;