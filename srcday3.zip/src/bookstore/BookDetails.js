import React, { Component } from 'react'
import { connect } from 'react-redux'



class BookDetails extends Component{

    render(){
if(!this.props.book) {
    return <div>select a book to get started</div>
}
   
    return (
<div>
    <h3>book details</h3>
    <p>Title : {this.props.book.title}</p>
    <p>Price : {this.props.book.price}</p>
</div>
         
    )
}}
function mapStateToProps(state){
    return{
    book:state.activeBook
}}

export default connect(mapStateToProps)(BookDetails)
 