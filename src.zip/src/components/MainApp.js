
import React, { Component } from 'react'
import Header from './Header'
import Footer from './Footer'
import Options from './Options'
import AddOption from './AddOption'
import Action from './Action'
import Counter from './Counter'

export default class MainApp extends Component {

componentDidMount(){


    try{
const json= localStorage.getItem('mydata')
const data= JSON.parse(json)
this.setState(()=>({data}))

    }catch(e){}
}
componentDidUpdate(){
try{
    const json= JSON.stringify(this.state.userdata)
    localStorage.setItem('mydata',json)

}catch(e){}
}



    constructor(props) {
        super(props)
        this.state = {
            userdata: props.userdata
        }
    }
    deleteAll = () => {
        this.setState(() => {
            return {
                userdata: []
            }
        })
    }

    addData = (data) => {
        this.setState((prevState) => {
            return {
                userdata: prevState.userdata.concat(data)
            }
        })
    }
    deleteonerecord = (data) => {

        this.setState((prevState) => ({
            userdata: prevState.userdata.filter((option) => data !== option)
        }))

    }


    render() {

        const hdata = 'welcome to header'
        return (
            <div>
                <p>welcome to MainApp</p>
                <Header mydata={hdata} />
                <Footer />
                <AddOption addData={this.addData} />
                <Action hasData={this.state.userdata.length > 0} />
                <Options userdata={this.state.userdata} deleteall={this.deleteAll} deleteone={
                    this.deleteonerecord} />

            </div>
        )
    }
}


MainApp.defaultProps={
    userdata:[]
}