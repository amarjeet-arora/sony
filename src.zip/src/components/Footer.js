
import React, { Component } from 'react'

export default class Footer extends Component {

    render() {
        return(
           <p>welcome to Footer</p> 
        )
    }
}