
import React, { Component } from 'react'
import Option from './Option'

export default class Options extends Component {

    render() {
        return(
           <div>
               <button onClick={this.props.deleteall}>Delete All</button>
               {
                this.props.userdata.map((mydata)=>
                <Option key={mydata} localdata={mydata}  deleteone={this.props.deleteone}/>) 
               }
                
           </div>
        )
    }
}