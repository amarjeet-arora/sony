
import React, { Component } from 'react'

export default class AddOption extends Component {
    constructor(props){
        super(props)
        this.state={
            collectedData:undefined
        }
    }
    callme=(e)=> {
        e.preventDefault()
        const userdata= e.target.elements.udata.value
        const collectedData= this.props.addData(userdata)

       this.setState(() =>{
           return {
               collectedData
           }
       })
    }
    render() {
        return (
            <div>

                 <form onSubmit={this.callme}>
                    Enter Name: <input type='text' name='udata' />
                    <button>add user</button>
                </form>

            </div>

        )
    }
}