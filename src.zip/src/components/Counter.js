
import React, { Component } from 'react'

export default class Counter extends Component {

    componentDidUpdate() {
        console.log('called')
    }
    constructor(props){
       super(props)
        this.decrement=this.decrement.bind(this)
        this.state={
            counter:0
        }
    }
increment=()=>{
   this.setState((privState) =>{
       return {
           counter: privState.counter+1
       }
   })
    
} 
decrement(){
    this.setState((privState) =>{
        return {
            counter: privState.counter-1
        }
    })
}
reset(){
    alert('i am called')
}

    render() {
        return(
            <div>
                <p>Counter {this.state.counter}</p> 

<button onClick={this.increment}>++</button>
<button onClick={this.decrement}>--</button>
<button onClick={this.reset}>reset</button>
            </div>
           
        )
    }
}