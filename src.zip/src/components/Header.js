
import React, { Component } from 'react'
// stateful component
/* export default class Header extends Component {

    render() {
        return(
           <p>{this.props.mydata}</p> 
        )
    }
} */

//stateless component

const Header=(props) =>{

    return(
<p>{props.mydata}</p>
    )
}
export default Header

