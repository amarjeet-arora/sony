
import React, { Component } from 'react'

export default class Option extends Component {

    render() {
        return(
          <div>
              {this.props.localdata}
              <button onClick={(e)=> {this.props.deleteone(this.props.localdata)}}>delete</button>
          </div>
        )
    }
}