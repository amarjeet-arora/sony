
import React, { Component } from 'react'

export default class Action extends Component {
callme(){
    alert('i am called')
}
    render() {
        return(
            <div>
                <p>welcome to Action</p> 
 
 <button disabled={!this.props.hasData} onClick={this.callme}>call</button>
 
            </div>
           
        )
    }
}